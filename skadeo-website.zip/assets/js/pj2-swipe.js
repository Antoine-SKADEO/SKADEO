/* =========================================================================
   PJ2 — Gabarit "split-screen" pour les pages projet (prototype)
   - Colonne gauche : titre / description / KPI / CTA, figés sur desktop.
   - Colonne droite : cartes vidéo qui scrollent en interne (scroll-snap).
     Une fois la dernière carte atteinte, le scroll de la souris/trackpad
     "déborde" naturellement sur la suite de la page (contexte détaillé,
     CTA contact) — le scroll-chaining ci-dessous fait en sorte que ça
     fonctionne peu importe où se trouve le curseur sur l'écran, pas
     seulement au survol direct de la colonne vidéo.
   Pas de navigation swipe/peek entre projets dans cette version : on quitte
   la page projet via le bouton fermer (retour à la liste).

   La lecture/contrôle vidéo (poster, play, son, plein écran) est gérée par
   le script existant de la page (.vid-card[data-vid]) : on ne le duplique
   pas ici, .pj2-media-item porte aussi la classe .vid-card.
   ========================================================================= */
(function(){
  "use strict";

  var mq900 = window.matchMedia("(min-width:900px)");

  /* ---- Scroll-chaining global (drainer la colonne droite d'abord) ---- */
  (function () {
    var media = document.getElementById("pj2Media");
    var wrapper = document.getElementById("pj2Wrapper");
    var stageEl = document.querySelector(".pj2-stage");
    if (!media || !wrapper || !stageEl) return;

    function isStuck() {
      if (!mq900.matches) return false;
      var r = wrapper.getBoundingClientRect();
      return r.top <= 1 && r.bottom >= (window.innerHeight - 1);
    }
    function scrollMax() { return media.scrollHeight - media.clientHeight; }
    function mediaAtTop() { return media.scrollTop <= 0; }
    function mediaAtBottom() { return media.scrollTop >= scrollMax() - 1; }

    var settleT = null;
    function beginDrive() {
      if (media.style.scrollSnapType !== "none") media.style.scrollSnapType = "none";
      clearTimeout(settleT);
    }
    function scheduleSettle() {
      clearTimeout(settleT);
      settleT = setTimeout(settle, 140);
    }
    function settle() {
      var items = media.querySelectorAll(".pj2-media-item");
      if (items.length) {
        var center = media.scrollTop + media.clientHeight / 2;
        var best = null, bestDist = Infinity;
        for (var i = 0; i < items.length; i++) {
          var it = items[i];
          var itCenter = it.offsetTop + it.clientHeight / 2;
          var dist = Math.abs(itCenter - center);
          if (dist < bestDist) { bestDist = dist; best = it; }
        }
        if (best) {
          // La 1re carte s'aligne sur son bord haut (comme en CSS via
          // scroll-snap-align:start + scroll-padding-top), pas sur son
          // centre : son haut doit rester au même niveau que le 1er texte
          // de la colonne gauche, à scrollTop 0.
          var target = best === items[0]
            ? 0
            : Math.max(0, Math.min(scrollMax(), best.offsetTop + best.clientHeight / 2 - media.clientHeight / 2));
          media.scrollTo({ top: target, behavior: "smooth" });
        }
      }
      media.style.scrollSnapType = "";
    }
    function driveScroll(delta) {
      beginDrive();
      media.scrollTop = Math.max(0, Math.min(scrollMax(), media.scrollTop + delta));
      scheduleSettle();
    }

    document.addEventListener("wheel", function (e) {
      if (e.deltaY === 0) return;
      if (!isStuck()) return;
      if (e.deltaY > 0 && mediaAtBottom()) return;
      if (e.deltaY < 0 && mediaAtTop()) return;
      e.preventDefault();
      driveScroll(e.deltaY);
    }, { passive: false });

    var touchY = null;
    document.addEventListener("touchstart", function (e) {
      touchY = (mq900.matches && e.touches && e.touches.length) ? e.touches[0].clientY : null;
    }, { passive: true });
    document.addEventListener("touchmove", function (e) {
      if (touchY === null || !e.touches || !e.touches.length) return;
      var newY = e.touches[0].clientY;
      var delta = touchY - newY;
      if (!isStuck()) { touchY = newY; return; }
      if (delta > 0 && mediaAtBottom()) { touchY = newY; return; }
      if (delta < 0 && mediaAtTop()) { touchY = newY; return; }
      e.preventDefault();
      driveScroll(delta);
      touchY = newY;
    }, { passive: false });
  })();
})();
